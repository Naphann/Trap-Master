Hi and thank you for downloading this 3D model of Jetstorm_477 !

	Model uploaded in .stl (StereoLithography) and .obj (OBJ Wavefront) formats.

	Get the full version (All colors, textures, 12 formats ...) of this model on : www.turbosquid.com
	To this page : http://www.turbosquid.com/FullPreview/Index.cfm?ID=1044621
	My Artist page : http://www.turbosquid.com/Search/Artists/Jetstorm_477

	Don't hesitate to leave me a comment on tf3dm.com at the model page or
	send me a message, in case of problems or suggestions !

Enjoy ;)
L�o C.